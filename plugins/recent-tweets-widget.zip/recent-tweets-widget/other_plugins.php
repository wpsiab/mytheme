 <?php add_thickbox(); ?>
 <div class="wrap">
	<?php screen_icon(); ?>
	<h2>Other Plugins</h2>
	
        <p style="border:1px solid #CCCCCC;background:#FFFFFF;padding:8px;">
                <a href="<?php echo admin_url( 'plugin-install.php?tab=plugin-information&plugin=sumome&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">SumoMe</a> - Tools to grow your Email List, Social Sharing and Analytics
                <br /><br />
                <a href="<?php echo admin_url('plugin-install.php?tab=plugin-information&plugin=google-analyticator&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">Google Analyticator</a> - Easily view your Google Analytics and real-time statistics
                <br /><br />
                <a href="<?php echo admin_url('plugin-install.php?tab=plugin-information&plugin=social-share-boost&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">Social Share Boost</a> - Boost Your Social Sharing by automatically adding various social share tools above or below the posts, page and excerpts.
        </p>
</div>